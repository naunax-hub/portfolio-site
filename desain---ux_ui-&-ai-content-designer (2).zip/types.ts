export interface Project {
  id: string;
  title: string;
  category: string;
  image: string;
  type: 'ux' | 'ai' | 'art';
  description?: string;
}

export interface Stat {
  value: string;
  label: string;
}

export interface Experience {
  role: string;
  company: string;
  period: string;
  description: string;
}

export interface EducationItem {
  title: string;
  institution: string;
  year: string;
}