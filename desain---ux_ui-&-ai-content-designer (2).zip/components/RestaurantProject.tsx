
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Smartphone, 
  Tablet, 
  Monitor, 
  Layout, 
  Layers, 
  BarChart3, 
  Zap, 
  Clock,
  CheckCircle2
} from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';
import { ScrollReveal } from './ScrollReveal';

export const RestaurantProject: React.FC<{ onBack: () => void, onContact: () => void }> = ({ onBack, onContact }) => {
  return (
    <div className="bg-white min-h-screen text-black font-body selection:bg-black selection:text-white pb-20">
      
      {/* 1. HEADER BAR */}
      <div className="fixed top-0 left-0 right-0 z-[120] bg-white/90 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-gray-100">
        <GlobalBackButton onClick={onBack} />
        <div className="text-[10px] font-product font-bold uppercase tracking-[0.3em] text-gray-400">
          UX/UI White Label Case Study
        </div>
      </div>

      {/* 2. HERO SECTION */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden bg-gray-900">
        <img 
          src="https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=2000" 
          className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale"
          alt="Restaurant Background"
        />
        <div className="relative z-10 text-center px-6 max-w-5xl">
          <ScrollReveal>
            <span className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-product font-bold uppercase tracking-widest text-white mb-8 border border-white/20">
              Syntphony Restaurant
            </span>
            <h1 className="text-5xl md:text-7xl font-serif text-white mb-8 leading-tight">
              L'ecosistema digitale per la <br/> <span className="italic opacity-80">ristorazione moderna</span>
            </h1>
            <p className="text-white/70 text-lg md:text-xl max-w-3xl mx-auto font-body leading-relaxed mb-0">
              Un’unica piattaforma, quattro potenti moduli interconnessi. Dalla presa dell'ordine all'analisi dei dati, abbiamo ridisegnato l'esperienza di gestione del ristorante.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* 3. INTRODUZIONE AL PROGETTO */}
      <section className="py-32 px-6 max-w-4xl mx-auto">
        <ScrollReveal>
          <div className="flex flex-col md:flex-row gap-16 items-start">
            <div className="w-full md:w-1/3">
              <h2 className="text-4xl font-serif italic border-l-4 border-black pl-6">
                La sincronizzazione perfetta
              </h2>
            </div>
            <div className="w-full md:w-2/3">
              <p className="text-xl text-gray-600 leading-relaxed font-body mb-8">
                Il progetto nasce dall'esigenza di trasformare la complessità operativa di un ristorante in un flusso di lavoro lineare e intuitivo. Abbiamo sviluppato una suite White Label completa che copre ogni aspetto del servizio.
              </p>
              <p className="text-gray-500 font-body">
                Ogni interfaccia è stata progettata con una UX coerente per ridurre i tempi di apprendimento e massimizzare l'efficiency operativa tra i diversi reparti del locale.
              </p>
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* 4. I 4 PILASTRI - GRID 2x2 */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-px bg-gray-200 border border-gray-200">
            
            {/* 01. Cameriere */}
            <div className="bg-white p-12 md:p-20">
              <ScrollReveal>
                <div className="flex items-center gap-4 mb-8">
                  <span className="text-4xl font-serif italic text-gray-200">01</span>
                  <div className="h-px flex-1 bg-gray-100"></div>
                  <Smartphone className="text-gray-400" size={24} />
                </div>
                <h3 className="text-3xl font-serif mb-4">Cameriere (Smart Ordering)</h3>
                <p className="text-xs font-product font-bold text-gray-400 uppercase tracking-widest mb-8 italic">Velocità e precisione al tavolo</p>
                <div className="aspect-[9/16] bg-gray-100 rounded-[2.5rem] border-[8px] border-gray-900 overflow-hidden mb-12 max-w-[280px] mx-auto shadow-2xl">
                  <img src="https://images.unsplash.com/photo-1556742044-3c52d6e88c62?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover grayscale" alt="App Cameriere" />
                </div>
                <div className="space-y-6 text-sm text-gray-600 font-body">
                  <p>L'applicazione mobile dedicata al personale di sala. Progettata per essere utilizzata in movimento, permette una presa dell'ordine rapida e senza errori.</p>
                  <div className="bg-gray-50 p-6 rounded-sm">
                    <h4 className="font-product font-bold text-black uppercase tracking-widest text-[10px] mb-3">Design Focus</h4>
                    <p className="italic text-xs">Bottoni ampi per l'uso rapido con una mano sola, contrasto elevato per leggibilità in condizioni di scarsa luce ambientale.</p>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* 02. Gestione Sala */}
            <div className="bg-white p-12 md:p-20">
              <ScrollReveal>
                <div className="flex items-center gap-4 mb-8">
                  <span className="text-4xl font-serif italic text-gray-200">02</span>
                  <div className="h-px flex-1 bg-gray-100"></div>
                  <Tablet className="text-gray-400" size={24} />
                </div>
                <h3 className="text-3xl font-serif mb-4">Gestione Sala (Floor Management)</h3>
                <p className="text-xs font-product font-bold text-gray-400 uppercase tracking-widest mb-8 italic">Il controllo totale in tempo reale</p>
                <div className="aspect-[4/3] bg-gray-100 rounded-xl border-[8px] border-gray-900 overflow-hidden mb-12 shadow-2xl">
                  <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale" alt="Floor Management" />
                </div>
                <div className="space-y-6 text-sm text-gray-600 font-body">
                  <p>Il pannello di comando per il Maître. Una mappa interattiva che offre una visione d'insieme immediata sull'occupazione e sull'andamento del servizio.</p>
                  <div className="bg-gray-50 p-6 rounded-sm">
                    <h4 className="font-product font-bold text-black uppercase tracking-widest text-[10px] mb-3">Key Features</h4>
                    <ul className="space-y-2 text-xs">
                      <li>• Mappa tavoli drag-and-drop</li>
                      <li>• Codici colore semantici per stato tavolo</li>
                      <li>• Monitoraggio tempi di attesa</li>
                    </ul>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* 03. Cucina */}
            <div className="bg-white p-12 md:p-20">
              <ScrollReveal>
                <div className="flex items-center gap-4 mb-8">
                  <span className="text-4xl font-serif italic text-gray-200">03</span>
                  <div className="h-px flex-1 bg-gray-100"></div>
                  <Layout className="text-gray-400" size={24} />
                </div>
                <h3 className="text-3xl font-serif mb-4">Cucina (Kitchen Display)</h3>
                <p className="text-xs font-product font-bold text-gray-400 uppercase tracking-widest mb-8 italic">L'orchestra dietro le quinte</p>
                <div className="aspect-video bg-black rounded-sm border border-gray-800 overflow-hidden mb-12 shadow-2xl relative">
                  <img src="https://images.unsplash.com/photo-1551218808-94e220e084d2?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover opacity-60 grayscale" alt="KDS System" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-black/80 backdrop-blur-md p-6 border border-white/10 text-white font-mono text-[10px] uppercase tracking-widest">
                      KDS Terminal _ Active
                    </div>
                  </div>
                </div>
                <div className="space-y-6 text-sm text-gray-600 font-body">
                  <p>Addio alle comande cartacee. Il modulo cucina digitalizza il flusso di lavoro della brigata, organizzando priorità e tempi di preparazione.</p>
                  <div className="bg-gray-900 p-6 rounded-sm text-gray-400">
                    <h4 className="font-product font-bold text-white uppercase tracking-widest text-[10px] mb-3">Design Focus: Dark Mode</h4>
                    <p className="italic text-xs">Interfaccia scura per ridurre l'affaticamento visivo in cucina e tipografia extralarge leggibile a 3 metri di distanza.</p>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* 04. Back Office */}
            <div className="bg-white p-12 md:p-20">
              <ScrollReveal>
                <div className="flex items-center gap-4 mb-8">
                  <span className="text-4xl font-serif italic text-gray-200">04</span>
                  <div className="h-px flex-1 bg-gray-100"></div>
                  <BarChart3 className="text-gray-400" size={24} />
                </div>
                <h3 className="text-3xl font-serif mb-4">Back Office (Analytics)</h3>
                <p className="text-xs font-product font-bold text-gray-400 uppercase tracking-widest mb-8 italic">Dati che guidano le decisioni</p>
                <div className="aspect-video bg-white rounded-sm border border-gray-200 overflow-hidden mb-12 shadow-xl p-4">
                  <div className="w-full h-full bg-gray-50 flex flex-col gap-2 p-4">
                     <div className="flex gap-2">
                       <div className="h-4 w-20 bg-gray-200"></div>
                       <div className="h-4 w-12 bg-gray-200"></div>
                     </div>
                     <div className="flex-1 flex items-end gap-1">
                        {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                          <div key={i} className="flex-1 bg-gray-300" style={{ height: `${h}%` }}></div>
                        ))}
                     </div>
                  </div>
                </div>
                <div className="space-y-6 text-sm text-gray-600 font-body">
                  <p>Il cervello amministrativo del sistema. Una dashboard completa per configurare l'intero ecosistema e analizzare le performance del business.</p>
                  <div className="bg-gray-50 p-6 rounded-sm">
                    <h4 className="font-product font-bold text-black uppercase tracking-widest text-[10px] mb-3">Data Visualization</h4>
                    <p className="italic text-xs">Grafici essenziali e dashboard modulari per una navigazione gerarchica semplificata dei report vendite.</p>
                  </div>
                </div>
              </ScrollReveal>
            </div>

          </div>
        </div>
      </section>

      {/* 5. CONCLUSIONE / DESIGN SYSTEM */}
      <section className="py-32 px-6 bg-white text-center">
        <ScrollReveal>
          <div className="max-w-3xl mx-auto">
            <h2 className="text-5xl font-serif mb-8 italic">Un Design System Scalabile</h2>
            <p className="text-xl text-gray-600 leading-relaxed font-body mb-16">
              Syntphony Restaurant non è solo un software, è un linguaggio visivo coerente applicato a dispositivi diversi. Il risultato è un prodotto digitale che unisce estetica minimale e massima funzionalità.
            </p>
            <div className="flex flex-wrap justify-center gap-12 pt-12 border-t border-gray-100">
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Role</p>
                  <p className="text-sm font-bold">UX/UI Design</p>
               </div>
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Tools</p>
                  <p className="text-sm font-bold">Figma, Adobe Suite</p>
               </div>
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Year</p>
                  <p className="text-sm font-bold">2024</p>
               </div>
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* Footer */}
      <footer className="py-40 bg-black text-white text-center">
         <ScrollReveal>
            <h2 className="text-4xl md:text-6xl font-serif mb-12">Pronto per innovare la <br/> tua esperienza?</h2>
            <button 
              onClick={onContact}
              className="px-12 py-5 bg-white text-black rounded-full font-product font-bold uppercase tracking-widest hover:bg-gray-200 transition-all"
            >
              Lavoriamo Insieme
            </button>
         </ScrollReveal>
      </footer>
    </div>
  );
};
