
import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  ShoppingBag, 
  Heart, 
  Search, 
  User, 
  ChevronDown, 
  ChevronRight,
  ArrowRight,
  Play
} from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';
import { ScrollReveal } from './ScrollReveal';

export const DieselProject: React.FC<{ onBack: () => void, onContact: () => void }> = ({ onBack, onContact }) => {
  return (
    <div className="bg-white min-h-screen text-black font-body selection:bg-[#D92F2F] selection:text-white pb-20">
      
      {/* 1. MINIMAL HEADER BAR */}
      <div className="fixed top-0 left-0 right-0 z-[120] bg-white/90 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-gray-100">
        <GlobalBackButton onClick={onBack} />
        <div className="text-[10px] font-product font-bold uppercase tracking-[0.3em] text-gray-400">
          UI & AI project
        </div>
      </div>

      {/* 2. PROJECT TITLE SECTION */}
      <section className="pt-32 pb-20 px-6 max-w-4xl mx-auto text-center">
        <ScrollReveal>
          <span className="inline-block px-4 py-1.5 bg-gray-50 rounded-full text-[10px] font-product font-bold uppercase tracking-widest text-gray-400 mb-8">
            UI & AI project
          </span>
          <h1 className="text-6xl md:text-8xl font-serif font-medium tracking-tighter mb-6">
            Redesign Diesel
          </h1>
          <div className="inline-block bg-[#D92F2F] text-white px-4 py-1 text-[10px] font-product font-bold uppercase tracking-widest italic">
            Laura Memmola
          </div>
        </ScrollReveal>
      </section>

      {/* 3. CHALLENGE & CONCEPT */}
      <section className="py-20 px-6 max-w-3xl mx-auto">
        <ScrollReveal>
          <h2 className="text-3xl md:text-4xl font-serif mb-12">
            Elevare la Ribellione attraverso la chiarezza
          </h2>
          <div className="space-y-10">
            <div>
              <h3 className="text-xs font-product font-bold uppercase tracking-widest mb-4">The Challenge: <span className="text-gray-400 font-normal">Oltre il Caos Visivo</span></h3>
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                Il contesto attuale: Il sito web attuale di Diesel comunica fedelmente l'identità "grunge" e provocatoria del brand, ma lo fa a spese dell'usabilità. L'interfaccia, dominata da sfondi scuri e sovrapposizioni dense, crea un alto carico cognitivo. L'utente si trova immerso in un'esperienza visiva potente ma disorientante, dove la distinzione tra contenuto editoriale e call-to-action (acquisto) è spesso sfocata.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed font-body mt-6">
                La mia missione: Trasformare il disordine in design. L'obiettivo non era cancellare l'anima ribelle di Diesel, ma disciplinarla attraverso un sistema di design rigoroso ("Editorial Tech") che elevasse la percezione del brand da streetwear caotico a lusso contemporaneo.
              </p>
            </div>

            <div className="pt-10 border-t border-gray-100">
              <h3 className="text-xs font-product font-bold uppercase tracking-widest mb-4">Il Concept: <span className="text-gray-400 font-normal">"Organized Chaos" vs "Editorial Precision"</span></h3>
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                L'attuale sito web di Diesel punta tutto sull'atmosfera: è scuro, denso di immagini sovrapposte e utilizza un linguaggio visivo che mira a comunicare "ribellione" attraverso un certo disordine visivo. Tuttavia, questa scelta sacrifica spesso la leggibilità e l'esperienza d'acquisto (UX).
              </p>
              <p className="text-lg text-gray-600 leading-relaxed font-body mt-6">
                La mia proposta di redesign non cancella l'identità del brand, ma la matura. Passiamo da un'estetica "grunge digitale" a un approccio "Editorial Tech". Il sito diventa una galleria d'arte dove il prodotto è protagonista, fondendo la narrazione di marca (Storytelling) con una conversione e-commerce fluida.
              </p>
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* 4. HOMEPAGE SECTION */}
      <section className="py-32 bg-[#fafafa]">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <h2 className="text-4xl font-serif mb-8">Homepage</h2>
            <div className="max-w-2xl mb-16">
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                Ho eliminato il rumore visivo per focalizzare l'attenzione su un unico messaggio potente. La nuova Homepage utilizza immagini full-screen di alta qualità e una navigazione minimale. È una "copertina digitale" che stabilisce immediatamente il tono della collezione senza sopraffare l'utente.
              </p>
              <div className="mt-8 space-y-4">
                <p className="text-gray-800 font-bold font-product text-sm uppercase tracking-widest">Collection Page: Il Bianco come Spazio Attivo</p>
                <p className="text-gray-600 font-body">Per la pagina catalogo, ho abbandonato lo sfondo scuro in favore di un Paper White (#FAFAFA).</p>
                <ul className="list-disc list-inside text-gray-600 font-body ml-4 space-y-2">
                  <li><span className="font-bold text-black">Perché:</span> Lo sfondo chiaro esalta i dettagli del denim, le texture e i lavaggi dei tessuti, che sono visibili con maggiore fedeltà.</li>
                  <li><span className="font-bold text-black">Struttura:</span> Una griglia asimmetrica che alterna packshot di prodotto a immagini di campagna, rompendo la monotonia tipica degli e-commerce ma mantenendo una chiara gerarchia di vendita.</li>
                </ul>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
               <img src="https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&q=80&w=1200" className="w-full h-auto grayscale rounded-sm border border-gray-200" alt="Homepage Layout" />
               <img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1200" className="w-full h-auto rounded-sm border border-gray-200" alt="Homepage Detail" />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 5. PRODUCT DETAIL PAGE */}
      <section className="py-32 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <h2 className="text-4xl font-serif mb-8">Product Detail Page</h2>
            <div className="max-w-2xl mb-16">
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                Qui la logica si inverte. Per il dettaglio prodotto, ho scelto un approccio "Dark Mode".
              </p>
              <ul className="list-disc list-inside text-gray-600 font-body mt-6 ml-4 space-y-2">
                <li><span className="font-bold text-black">Perché:</span> Lo sfondo scuro isola il prodotto, creando un effetto "museale" o cinematografico. L'utente entra in una zona di focus dove esiste solo il capo d'abbigliamento. Le informazioni tecniche (vestibilità, tessuto) sono presentate con tipografia pulita per non rompere l'incantesimo visivo.</li>
              </ul>
            </div>
            
            <div className="bg-[#111] p-12 rounded-sm border border-gray-100 shadow-2xl">
              <div className="flex flex-col lg:flex-row gap-12 items-center">
                <div className="w-full lg:w-1/2 aspect-[3/4] bg-gray-900 rounded-sm overflow-hidden">
                   <img src="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale" alt="Product Dark Mode" />
                </div>
                <div className="w-full lg:w-1/2 text-white">
                   <h3 className="text-3xl font-product font-black uppercase tracking-tighter mb-2 italic">D-STRUKT - JEANS SLIM</h3>
                   <p className="text-gray-500 font-product font-bold text-sm mb-10">€ 145,00</p>
                   
                   <div className="mb-8">
                     <p className="text-[10px] font-product font-bold uppercase tracking-widest text-gray-500 mb-3">Color</p>
                     <div className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-black border border-white"></div>
                        <div className="w-6 h-6 rounded-full bg-gray-700"></div>
                        <div className="w-6 h-6 rounded-full bg-blue-900"></div>
                     </div>
                   </div>

                   <div className="mb-12">
                     <p className="text-[10px] font-product font-bold uppercase tracking-widest text-gray-500 mb-3">Taglia</p>
                     <div className="flex gap-4">
                        {['SS', 'M', 'L', 'XL'].map(s => (
                          <div key={s} className="w-10 h-10 border border-white/20 flex items-center justify-center text-[10px] font-product font-bold uppercase hover:border-white cursor-pointer transition-colors">{s}</div>
                        ))}
                     </div>
                   </div>

                   <button className="w-full bg-[#D92F2F] text-white py-4 font-product font-black uppercase italic tracking-[0.2em] text-xs mb-4">Aggiungi al Carrello</button>
                   <button className="w-full border border-white/20 py-4 font-product font-bold uppercase tracking-widest text-xs">Metodi di Ordine</button>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 6. CHECKOUT SECTION */}
      <section className="py-32 bg-[#fafafa]">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <h2 className="text-4xl font-serif mb-8">Checkout</h2>
            <div className="max-w-2xl mb-16">
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                Il carrello abbandona ogni velleità artistica per la pura funzionalità. Sfondo chiaro, layout pulito, totale evidenza. In questa fase, la "ribellione" lascia spazio alla rassicurazione e alla semplicità, riducendo drasticamente il tasso di abbandono.
              </p>
            </div>

            <div className="bg-white p-12 rounded-sm border border-gray-100 shadow-xl max-w-4xl mx-auto">
               <h3 className="text-3xl font-serif italic text-center mb-16">Il Tuo Carrello</h3>
               <div className="flex flex-col lg:flex-row gap-16">
                  <div className="flex-1 space-y-12">
                     <div className="flex gap-8 border-b border-gray-50 pb-8">
                        <div className="w-32 h-40 bg-gray-50 rounded-sm">
                           <img src="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=300" className="w-full h-full object-cover grayscale" alt="Item" />
                        </div>
                        <div className="flex-1">
                           <h4 className="font-product font-black uppercase tracking-tight text-sm">D-Viker Straight Jeans</h4>
                           <p className="text-xs text-gray-400 mt-2 font-body">Taglia: 32 | Colore: Blu Scuro | Quantità: 1</p>
                           <p className="text-sm font-product font-bold mt-4 italic">€ 250,00</p>
                        </div>
                     </div>
                  </div>
                  <div className="w-full lg:w-80 bg-gray-50 p-8 rounded-sm">
                     <h5 className="font-product font-bold uppercase tracking-widest text-[10px] mb-8">Riepilogo Ordine</h5>
                     <div className="space-y-4 mb-8">
                        <div className="flex justify-between text-xs text-gray-500 font-body"><span>Subtotale</span><span>€ 250,00</span></div>
                        <div className="flex justify-between text-xs text-gray-500 font-body"><span>Spedizione</span><span>Gratuita</span></div>
                        <div className="flex justify-between font-product font-bold text-lg pt-4 border-t border-gray-200"><span>Totale</span><span>€ 250,00</span></div>
                     </div>
                     <button className="w-full bg-[#D92F2F] text-white py-5 font-product font-black uppercase italic tracking-[0.2em] text-xs shadow-lg shadow-red-500/20">Procedi all'acquisto</button>
                  </div>
               </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 7. ADAPTIVE NAVIGATION */}
      <section className="py-32 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <h2 className="text-4xl font-serif mb-8">Adaptive Navigation</h2>
            <div className="max-w-2xl mb-16">
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                Un elemento chiave del redesign è l'header dinamico, che cambia comportamento in base al contenuto per guidare inconsciamente l'utente.
              </p>
              <ul className="mt-8 space-y-6 font-body text-gray-600">
                <li><span className="font-bold text-black font-product text-xs uppercase tracking-widest">Header Nero (Structure Mode):</span> Utilizzato su sfondi chiari (Cataloghi, Testi). Crea un forte contrasto, comunica autorità e incornicia il contenuto, segnalando una fase di lettura o decisione razionale.</li>
                <li><span className="font-bold text-black font-product text-xs uppercase tracking-widest">Header Trasparente/Bianco (Immersion Mode):</span> Utilizzato su video o immagini full-screen. L'interfaccia "scompare" per permettere al contenuto visivo di occupare tutto lo spazio (bleed layout). Segnala una fase di scoperta ed emozione.</li>
              </ul>
              <p className="mt-8 text-gray-600 font-body">Questa alternanza non è solo estetica, ma funzionale: aiuta l'utente a capire intuitivamente in quale parte del funnel si trova (Ispirazione vs Transazione).</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
               <div className="bg-gray-100 aspect-video rounded-sm overflow-hidden relative border border-gray-200 shadow-sm">
                  <div className="absolute top-0 left-0 right-0 h-16 bg-black flex items-center justify-center text-white text-[10px] font-product font-bold uppercase tracking-[0.4em]">Structure Mode Header</div>
                  <div className="h-full flex items-center justify-center font-serif italic text-gray-400">Content Area</div>
               </div>
               <div className="bg-gray-800 aspect-video rounded-sm overflow-hidden relative border border-gray-200 shadow-sm">
                  <div className="absolute top-0 left-0 right-0 h-16 bg-transparent flex items-center justify-center text-white text-[10px] font-product font-bold uppercase tracking-[0.4em]">Immersion Mode Header</div>
                  <img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover grayscale opacity-50" alt="Full Bleed Content" />
               </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 8. VISUAL IDENTITY & PALETTE */}
      <section className="py-32 bg-white border-t border-gray-100">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <h2 className="text-4xl font-serif mb-8">Visual Identity & Palette</h2>
            <div className="max-w-2xl mb-16">
              <p className="text-lg text-gray-600 leading-relaxed font-body">
                La palette è stata ridotta all'essenziale per comunicare autorità:
              </p>
              <ul className="mt-6 space-y-3 font-body text-gray-600">
                <li><span className="font-bold text-black">• Ink Black & Paper White:</span> La base del contrasto, che garantisce leggibilità AAA.</li>
                <li><span className="font-bold text-black">• Diesel Red:</span> Utilizzato esclusivamente per le azioni primarie ("Acquista", "Procedi"). Usarlo con parsimonia lo rende un potente catalizzatore di attenzione.</li>
                <li><span className="font-bold text-black">• Tipografia Ibrida:</span> Un font Serif per i titoli (Narrativa) abbinato a un Sans-Serif geometrico per i dati (Tecnica).</li>
              </ul>
            </div>

            <div className="space-y-24">
              {/* Color Palette Display */}
              <div>
                <h3 className="text-[10px] font-product font-bold uppercase tracking-widest text-gray-400 mb-8">Color Palette</h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                  {[
                    { hex: "#000000", name: "Ink Black" },
                    { hex: "#FFFFFF", name: "Paper White" },
                    { hex: "#F5F5F5", name: "Cool Grey" },
                    { hex: "#333333", name: "Dark Grey" },
                    { hex: "#D92F2F", name: "Diesel Red" }
                  ].map((c, i) => (
                    <div key={i} className="space-y-3">
                       <div className="aspect-square w-full rounded-sm shadow-inner border border-gray-100" style={{ backgroundColor: c.hex }}></div>
                       <p className="text-[10px] font-product font-bold uppercase tracking-widest text-black">{c.hex}</p>
                       <p className="text-xs text-gray-400 font-body">{c.name}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Typography Display */}
              <div>
                <h3 className="text-[10px] font-product font-bold uppercase tracking-widest text-gray-400 mb-8">Typography</h3>
                <div className="grid md:grid-cols-2 gap-16">
                  <div className="space-y-8">
                     <p className="text-6xl font-serif italic leading-tight">Il denim è <br/>la nostra <br/>eredità.</p>
                     <p className="text-xs text-gray-400 font-product uppercase tracking-widest">Heading / Storytelling (Kannada MN / Playfair)</p>
                  </div>
                  <div className="space-y-8">
                     <p className="text-4xl font-product font-black uppercase italic tracking-tighter">€ 250,00 <br/> ADD TO CART</p>
                     <p className="text-xs text-gray-400 font-product uppercase tracking-widest">Technical / Data (Inter UI)</p>
                  </div>
                </div>
              </div>

              {/* UI Components Display */}
              <div>
                 <h3 className="text-[10px] font-product font-bold uppercase tracking-widest text-gray-400 mb-8">UI Components</h3>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-start">
                    <div className="space-y-4">
                       <button className="w-full bg-[#D92F2F] text-white py-3 font-product font-black uppercase italic tracking-widest text-[10px]">Procedi all'acquisto</button>
                       <button className="w-full bg-black text-white py-3 font-product font-black uppercase italic tracking-widest text-[10px]">Aggiungi al Carrello</button>
                       <button className="w-full border border-black py-3 font-product font-bold uppercase tracking-widest text-[10px]">Trova in Negozio</button>
                    </div>
                    <div className="space-y-4">
                       <input type="text" placeholder="Email" className="w-full px-4 py-3 border border-gray-200 text-xs font-body focus:outline-none focus:border-black" />
                       <div className="flex gap-4">
                          <Heart size={20} className="text-gray-400" />
                          <ShoppingBag size={20} className="text-gray-400" />
                          <Search size={20} className="text-gray-400" />
                          <User size={20} className="text-gray-400" />
                       </div>
                    </div>
                 </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 9. RISULTATO FINALE */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <ScrollReveal>
            <h2 className="text-4xl md:text-5xl font-serif mb-12">Risultato finale</h2>
            <p className="text-xl text-gray-600 leading-relaxed font-body italic mb-20">
              Il redesign propone un sito Diesel che non deve più "urlare" per farsi notare. È un'interfaccia che parla con l'autorità di un leader del settore, offrendo un'esperienza d'acquisto fluida, accessibile e profondamente legata al DNA del brand.
            </p>
            <div className="relative aspect-video rounded-sm overflow-hidden shadow-2xl group border border-gray-100">
               <img src="https://images.unsplash.com/photo-1535905557558-afc4877a26fc?auto=format&fit=crop&q=80&w=1600" className="w-full h-full object-cover grayscale opacity-80" alt="Laptop Preview" />
               <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-white/10 backdrop-blur-md border border-white/30 flex items-center justify-center text-white cursor-pointer hover:bg-[#D92F2F] hover:border-[#D92F2F] transition-all">
                     <Play fill="currentColor" size={24} />
                  </div>
               </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 10. CONNECT FOOTER (CUSTOM FOR PROJECT) */}
      <footer className="py-40 bg-white border-t border-gray-100 text-center">
         <div className="max-w-4xl mx-auto px-6">
            <ScrollReveal>
               <h2 className="text-4xl md:text-6xl font-serif mb-12 leading-tight">
                  Connettiamoci e condividiamo idee e progetti.
               </h2>
               <button 
                 onClick={onContact}
                 className="px-12 py-5 bg-black text-white rounded-full font-product font-bold uppercase tracking-widest hover:bg-[#D92F2F] transition-all transform hover:scale-105"
               >
                  Contattami
               </button>
            </ScrollReveal>
         </div>
      </footer>
    </div>
  );
};
