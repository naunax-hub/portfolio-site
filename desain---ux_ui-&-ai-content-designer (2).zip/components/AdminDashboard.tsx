
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Search, 
  Image as ImageIcon, 
  Film, 
  Folder, 
  Settings, 
  MoreVertical, 
  Copy, 
  Trash2, 
  ArrowUpCircle,
  X,
  CheckCircle2,
  Database
} from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';
import { ScrollReveal } from './ScrollReveal';

interface MediaAsset {
  id: string;
  url: string;
  type: 'image' | 'video';
  name: string;
  project: string;
  size: string;
  dimensions?: string;
}

export const AdminDashboard: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'media' | 'projects' | 'settings'>('media');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  // Initial Mock Database
  const [assets] = useState<MediaAsset[]>([
    { id: '1', name: 'diesel_hero_fall.jpg', url: 'https://images.unsplash.com/photo-1542272604-787c3835535d', type: 'image', project: 'Diesel Redesign', size: '2.4 MB', dimensions: '3400 x 2200' },
    { id: '2', name: 'miracles_locandina.png', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853', type: 'image', project: 'AI believe in miracles', size: '1.8 MB', dimensions: '2000 x 3000' },
    { id: '3', name: 'fashion_board_01.jpg', url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d', type: 'image', project: 'Digital Content', size: '3.1 MB', dimensions: '1920 x 1080' },
    { id: '4', name: 'miracles_film_sequence.mp4', url: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1', type: 'video', project: 'AI believe in miracles', size: '45.2 MB' },
    { id: '5', name: 'animae_insta_feed.jpg', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe', type: 'image', project: 'Animae.ai', size: '1.2 MB', dimensions: '1080 x 1350' },
  ]);

  const handleSimulatedUpload = () => {
    setIsUploading(true);
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          setUploadProgress(0);
        }, 1000);
      }
    }, 200);
  };

  const filteredAssets = assets.filter(asset => 
    asset.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    asset.project.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-[#fafafa] min-h-screen text-black font-body flex">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r border-gray-100 p-8 flex flex-col fixed h-full z-10">
        <div className="mb-12">
          <div className="text-xl font-serif font-bold mb-1">Media Center</div>
          <div className="text-[9px] font-product font-bold uppercase tracking-widest text-gray-400">Database Management</div>
        </div>

        <nav className="space-y-4 flex-1">
          <button 
            onClick={() => setActiveTab('media')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === 'media' ? 'bg-black text-white' : 'text-gray-400 hover:text-black hover:bg-gray-50'}`}
          >
            <ImageIcon size={18} /> Media Library
          </button>
          <button 
            onClick={() => setActiveTab('projects')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === 'projects' ? 'bg-black text-white' : 'text-gray-400 hover:text-black hover:bg-gray-50'}`}
          >
            <Folder size={18} /> Project Data
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === 'settings' ? 'bg-black text-white' : 'text-gray-400 hover:text-black hover:bg-gray-50'}`}
          >
            <Settings size={18} /> Settings
          </button>
        </nav>

        <div className="pt-8 border-t border-gray-100">
           <button onClick={onBack} className="text-xs font-product font-bold uppercase tracking-widest text-gray-400 hover:text-black flex items-center gap-2">
             <X size={14} /> Exit Admin
           </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 ml-64 p-12">
        <header className="flex justify-between items-center mb-12">
           <div className="relative w-96">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search assets or projects..." 
                className="w-full pl-12 pr-4 py-3 bg-white border border-gray-100 rounded-xl text-sm focus:outline-none focus:border-black transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
           </div>
           <button 
             onClick={handleSimulatedUpload}
             className="bg-black text-white px-6 py-3 rounded-full flex items-center gap-3 text-sm font-medium hover:bg-gray-800 transition-all shadow-lg shadow-black/10"
           >
             <Plus size={18} /> Upload New Asset
           </button>
        </header>

        <AnimatePresence>
          {isUploading && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white border border-gray-100 p-6 rounded-2xl mb-12 flex items-center gap-6 shadow-sm"
            >
              <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center text-blue-500">
                <ArrowUpCircle size={24} className="animate-bounce" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-product font-bold uppercase tracking-widest">Uploading miracle_presentation.pdf</span>
                  <span className="text-sm font-mono text-gray-400">{uploadProgress}%</span>
                </div>
                <div className="h-2 w-full bg-gray-50 rounded-full overflow-hidden">
                   <motion.div 
                     className="h-full bg-black" 
                     initial={{ width: 0 }}
                     animate={{ width: `${uploadProgress}%` }}
                   />
                </div>
              </div>
              <button onClick={() => setIsUploading(false)} className="text-gray-400 hover:text-black"><X size={20}/></button>
            </motion.div>
          )}
        </AnimatePresence>

        {activeTab === 'media' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredAssets.map((asset) => (
              <motion.div 
                key={asset.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              >
                <div className="aspect-square bg-gray-50 relative overflow-hidden">
                  <img src={asset.url} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt={asset.name} />
                  <div className="absolute top-4 left-4">
                    {asset.type === 'video' ? (
                      <div className="bg-black/50 backdrop-blur-md p-2 rounded-lg text-white"><Film size={16}/></div>
                    ) : (
                      <div className="bg-white/80 backdrop-blur-md p-2 rounded-lg text-black"><ImageIcon size={16}/></div>
                    )}
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                    <button className="bg-white p-3 rounded-full text-black hover:bg-black hover:text-white transition-all"><Copy size={18}/></button>
                    <button className="bg-white p-3 rounded-full text-red-500 hover:bg-red-500 hover:text-white transition-all"><Trash2 size={18}/></button>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="text-sm font-product font-bold truncate mb-1">{asset.name}</h4>
                  <p className="text-[10px] text-gray-400 font-mono uppercase tracking-widest mb-4">{asset.project}</p>
                  <div className="flex justify-between items-center text-[10px] font-product font-bold text-gray-300">
                    <span>{asset.size}</span>
                    <span>{asset.dimensions || 'Dynamic'}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'projects' && (
          <div className="space-y-6">
            <h3 className="text-3xl font-serif mb-8">Portfolio Content Registry</h3>
            <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden">
               <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-100">
                     <tr>
                        <th className="px-8 py-4 text-[10px] font-product font-bold uppercase tracking-[0.2em] text-gray-400">Project Title</th>
                        <th className="px-8 py-4 text-[10px] font-product font-bold uppercase tracking-[0.2em] text-gray-400">Main Media ID</th>
                        <th className="px-8 py-4 text-[10px] font-product font-bold uppercase tracking-[0.2em] text-gray-400">Status</th>
                        <th className="px-8 py-4 text-[10px] font-product font-bold uppercase tracking-[0.2em] text-gray-400">Actions</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                     {[
                       { title: 'Diesel Redesign', media: 'diesel_h_01', status: 'Live' },
                       { title: 'AI believe in miracles', media: 'miracles_film_v1', status: 'Draft' },
                       { title: 'Animae.ai', media: 'ig_profile_sync', status: 'Live' },
                       { title: 'Restaurant Experience', media: 'rest_hero_99', status: 'Archived' }
                     ].map((row, i) => (
                       <tr key={i} className="hover:bg-gray-50 transition-colors">
                          <td className="px-8 py-6 text-sm font-medium">{row.title}</td>
                          <td className="px-8 py-6 text-xs font-mono text-gray-400">{row.media}</td>
                          <td className="px-8 py-6">
                             <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest ${row.status === 'Live' ? 'bg-green-50 text-green-600' : row.status === 'Draft' ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                                {row.status}
                             </span>
                          </td>
                          <td className="px-8 py-6">
                             <button className="text-gray-300 hover:text-black"><MoreVertical size={18}/></button>
                          </td>
                       </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
