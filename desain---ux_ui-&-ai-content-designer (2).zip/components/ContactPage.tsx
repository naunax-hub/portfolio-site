import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Bot, Linkedin, ArrowRight, Send } from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';

export const ContactPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  // AI Chat State
  const [messages, setMessages] = useState<{role: 'ai' | 'user', text: string}[]>([
    { role: 'ai', text: "Hello! I'm Laura's AI Assistant. How can I help you today?" }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  // Contact Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleQuestion = (question: string) => {
    setMessages(prev => [...prev, { role: 'user', text: question }]);
    setIsTyping(true);

    setTimeout(() => {
      let response = "";
      switch (question) {
        case "Are you available for freelance projects?":
          response = "Yes, Laura is currently open to select freelance opportunities in UX/UI Design and AI Content Strategy. Please email her directly to discuss your project!";
          break;
        case "What is your typical rate?":
          response = "Laura's rates vary depending on the project scope and complexity. She prefers to discuss requirements first to provide a tailored proposal.";
          break;
        case "Where are you based?":
          response = "Laura is based in Italy but works remotely with clients worldwide.";
          break;
        case "Can we schedule a call?":
          response = "Absolutely. You can reach out via email at laura.memmola89@gmail.com to schedule a convenient time.";
          break;
        default:
          response = "I'd recommend sending Laura an email for more specific details.";
      }
      
      setMessages(prev => [...prev, { role: 'ai', text: response }]);
      setIsTyping(false);
    }, 1500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = `Contact from Portfolio: ${formData.name}`;
    const body = `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`;
    window.location.href = `mailto:laura.memmola89@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const quickQuestions = [
    "Are you available for freelance projects?",
    "Where are you based?",
    "Can we schedule a call?"
  ];

  return (
    <div className="bg-white min-h-screen text-black font-body pt-20">
      <div className="px-6 md:px-20 py-12 max-w-7xl mx-auto">
         <GlobalBackButton onClick={onBack} />
         
         <div className="flex flex-col lg:flex-row gap-20 mt-16">
            {/* Left: Contact Info & Form */}
            <div className="w-full lg:w-1/2">
               <h1 className="text-6xl md:text-8xl font-serif font-bold text-black mb-12 leading-tight">
                 Get in<br/>Touch
               </h1>
               <p className="text-xl text-gray-600 font-body leading-relaxed mb-12 max-w-lg">
                 Whether you have a project in mind, a question about my work, or just want to say hello, I'd love to hear from you.
               </p>

               {/* Contact Details */}
               <div className="space-y-8 mb-16">
                  <div>
                     <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2 font-body">Email</h3>
                     <a href="mailto:laura.memmola89@gmail.com" className="text-2xl font-serif border-b border-black pb-1 hover:text-blue-600 hover:border-blue-600 transition-colors">
                        laura.memmola89@gmail.com
                     </a>
                  </div>

                  <div>
                     <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2 font-body">Social</h3>
                     <a href="https://www.linkedin.com/in/laura-memmola/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-xl font-medium hover:text-blue-600 transition-colors w-fit">
                        <Linkedin /> LinkedIn
                     </a>
                  </div>

                  <div>
                     <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2 font-body">Location</h3>
                     <p className="text-xl font-medium">Italy / Remote Worldwide</p>
                  </div>
               </div>

               {/* New Contact Form */}
               <div className="border-t border-gray-100 pt-12">
                   <h3 className="text-2xl font-serif font-bold mb-8">Send a Message</h3>
                   <form onSubmit={handleFormSubmit} className="space-y-8 max-w-lg">
                       <div className="space-y-2">
                           <label className="text-xs font-bold uppercase tracking-widest text-gray-400 font-body">Name</label>
                           <input 
                               type="text" 
                               value={formData.name}
                               onChange={e => setFormData({...formData, name: e.target.value})}
                               required
                               className="w-full border-b border-gray-200 py-3 font-body text-lg focus:outline-none focus:border-black transition-colors bg-transparent placeholder-gray-300"
                               placeholder="Your Name"
                           />
                       </div>
                       <div className="space-y-2">
                           <label className="text-xs font-bold uppercase tracking-widest text-gray-400 font-body">Email</label>
                           <input 
                               type="email" 
                               value={formData.email}
                               onChange={e => setFormData({...formData, email: e.target.value})}
                               required
                               className="w-full border-b border-gray-200 py-3 font-body text-lg focus:outline-none focus:border-black transition-colors bg-transparent placeholder-gray-300"
                               placeholder="your@email.com"
                           />
                       </div>
                       <div className="space-y-2">
                           <label className="text-xs font-bold uppercase tracking-widest text-gray-400 font-body">Message</label>
                           <textarea 
                               value={formData.message}
                               onChange={e => setFormData({...formData, message: e.target.value})}
                               required
                               rows={4}
                               className="w-full border-b border-gray-200 py-3 font-body text-lg focus:outline-none focus:border-black transition-colors bg-transparent placeholder-gray-300 resize-none"
                               placeholder="How can I help you?"
                           />
                       </div>
                       <button 
                           type="submit" 
                           className="group flex items-center gap-3 text-lg font-serif font-bold hover:opacity-70 transition-opacity"
                       >
                           Send Email <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                       </button>
                   </form>
               </div>
            </div>

            {/* Right: AI Chat Interface */}
            <div className="w-full lg:w-1/2">
               <div className="bg-gray-50 rounded-3xl p-8 h-[600px] flex flex-col shadow-sm border border-gray-100 relative overflow-hidden sticky top-24">
                  {/* AI Badge */}
                  <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1 bg-white rounded-full text-xs font-bold text-blue-600 shadow-sm z-10">
                     <Sparkles size={14} /> AI ASSISTANT
                  </div>

                  {/* Chat Area */}
                  <div className="flex-1 overflow-y-auto space-y-6 pr-2 mb-6 scrollbar-hide">
                     {messages.map((msg, i) => (
                        <motion.div 
                           key={i}
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                           <div className={`max-w-[80%] p-5 rounded-2xl text-lg font-body leading-relaxed ${
                              msg.role === 'user' 
                                 ? 'bg-black text-white rounded-br-none' 
                                 : 'bg-white text-gray-700 shadow-sm rounded-bl-none border border-gray-100'
                           }`}>
                              {msg.role === 'ai' && <Bot size={20} className="mb-2 text-blue-500" />}
                              {msg.text}
                           </div>
                        </motion.div>
                     ))}
                     {isTyping && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                           <div className="bg-white p-4 rounded-2xl rounded-bl-none shadow-sm border border-gray-100 flex gap-2">
                              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></span>
                              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></span>
                           </div>
                        </motion.div>
                     )}
                     <div ref={messagesEndRef} />
                  </div>

                  {/* Quick Questions */}
                  <div className="mt-auto">
                     <p className="text-xs text-gray-400 font-mono uppercase tracking-widest mb-4">Ask me anything</p>
                     <div className="flex flex-wrap gap-3">
                        {quickQuestions.map((q, i) => (
                           <button 
                              key={i}
                              onClick={() => handleQuestion(q)}
                              className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm text-gray-600 hover:border-black hover:text-black transition-colors"
                           >
                              {q}
                           </button>
                        ))}
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};