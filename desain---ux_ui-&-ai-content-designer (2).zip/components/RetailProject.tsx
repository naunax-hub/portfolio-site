
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Smartphone, 
  Scan, 
  ShoppingBag, 
  Users, 
  Zap, 
  BarChart, 
  MapPin, 
  Clock,
  CheckCircle2,
  Database,
  ArrowRight
} from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';
import { ScrollReveal } from './ScrollReveal';

export const RetailProject: React.FC<{ onBack: () => void, onContact: () => void }> = ({ onBack, onContact }) => {
  return (
    <div className="bg-white min-h-screen text-black font-body selection:bg-[#007bff] selection:text-white pb-20">
      
      {/* 1. HEADER BAR */}
      <div className="fixed top-0 left-0 right-0 z-[120] bg-white/90 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-gray-100">
        <GlobalBackButton onClick={onBack} />
        <div className="text-[10px] font-product font-bold uppercase tracking-[0.3em] text-gray-400">
          UX/UI Retail Strategy
        </div>
      </div>

      {/* 2. HERO SECTION */}
      <section className="relative h-[85vh] flex items-center justify-center overflow-hidden bg-[#0056b3]">
        <img 
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=2000" 
          className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale mix-blend-overlay"
          alt="Retail Innovation"
        />
        <div className="relative z-10 text-center px-6 max-w-5xl">
          <ScrollReveal>
            <span className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-product font-bold uppercase tracking-widest text-white mb-8 border border-white/20">
              UX/UI Design
            </span>
            <h1 className="text-5xl md:text-7xl font-serif text-white mb-8 leading-tight">
              Syntphony Retail Experience: <br/> 
              <span className="italic opacity-90">L’innovazione omnicanale</span>
            </h1>
            <p className="text-white/80 text-lg md:text-xl max-w-3xl mx-auto font-body leading-relaxed mb-0">
              Un sistema integrato progettato per rivoluzionare il percorso d'acquisto, fondendo l'autonomia del self-scanning con la versatilità di un'app mobile.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* 3. INTRODUZIONE AL PROGETTO */}
      <section className="py-32 px-6 max-w-6xl mx-auto">
        <ScrollReveal>
          <div className="grid md:grid-cols-12 gap-16 items-start">
            <div className="md:col-span-5">
              <h2 className="text-4xl md:text-5xl font-serif leading-tight">
                Il Progetto: <br/> 
                <span className="italic text-gray-400">Visione Omnicanale</span>
              </h2>
            </div>
            <div className="md:col-span-7 space-y-6">
              <p className="text-xl text-gray-600 leading-relaxed font-body">
                L'obiettivo strategico è rendere la tecnologia invisibile, facilitando la relazione tra brand e consumatore attraverso interazioni intuitive e un design coerente. 
              </p>
              <p className="text-gray-500 font-body">
                Questo progetto unisce due potenti strumenti: un'applicazione di Self Scanning per il punto vendita e una Mobile App che estende l'esperienza oltre i confini fisici del negozio, offrendo una soluzione completa per il retail contemporaneo.
              </p>
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* 4. VANTAGGI DELL'ADOZIONE */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <ScrollReveal>
             <div className="mb-16">
                <h3 className="text-xs font-product font-bold text-gray-400 uppercase tracking-widest mb-4">I Benefici</h3>
                <h2 className="text-4xl font-serif italic">Vantaggi dell'adozione</h2>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
                {[
                  { icon: <Users size={24}/>, title: "Autonomia utenti", desc: "Gestione del percorso d'acquisto in libertà." },
                  { icon: <Clock size={24}/>, title: "Riduzione code", desc: "Checkout rapido per un flusso migliore." },
                  { icon: <Zap size={24}/>, title: "Omnicanalità", desc: "Coerenza tra canale fisico e digitale." },
                  { icon: <Database size={24}/>, title: "Ottimizzazione", desc: "Gestione efficiente dell'inventario." },
                  { icon: <BarChart size={24}/>, title: "Real-time Data", desc: "Insight dettagliati sui comportamenti." }
                ].map((item, i) => (
                  <div key={i} className="bg-white p-8 rounded-sm border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="text-[#007bff] mb-6">{item.icon}</div>
                    <h4 className="font-serif text-lg mb-3">{item.title}</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
             </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 5. SEZIONE 01: SELF SCANNING */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <ScrollReveal>
             <div className="flex flex-col lg:flex-row items-center gap-20">
                <div className="w-full lg:w-1/2">
                   <div className="flex items-center gap-4 mb-8">
                     <span className="text-4xl font-serif italic text-gray-200">01</span>
                     <div className="h-px flex-1 bg-gray-100"></div>
                     <Scan className="text-[#007bff]" size={24} />
                   </div>
                   <h2 className="text-4xl font-serif mb-6">Self Scanning: <br/> <span className="italic text-gray-400">L'autonomia nel punto vendita</span></h2>
                   <p className="text-lg text-gray-600 mb-8 leading-relaxed font-body">
                     L'applicazione per il Self Scanning trasforma lo smartphone del cliente in un assistente di spesa personale. Progettata per essere intuitiva, permette di scansionare i prodotti direttamente dallo scaffale.
                   </p>
                   <ul className="space-y-6 mb-12">
                      {[
                        { t: "Scansione Intuitiva", d: "Interfaccia semplice con feedback immediato sulla scansione." },
                        { t: "Totale in Tempo Reale", d: "Controllo costante della spesa per una maggiore consapevolezza." },
                        { t: "Pagamento Veloce", d: "Integrazione con sistemi di pagamento digitale per un checkout senza intoppi." }
                      ].map((feature, i) => (
                        <li key={i} className="flex items-start gap-4">
                           <CheckCircle2 size={18} className="text-[#007bff] mt-1 shrink-0" />
                           <div>
                              <h4 className="font-product font-bold text-xs uppercase tracking-widest mb-1">{feature.t}</h4>
                              <p className="text-sm text-gray-500">{feature.d}</p>
                           </div>
                        </li>
                      ))}
                   </ul>
                </div>
                <div className="w-full lg:w-1/2 grid grid-cols-2 gap-6">
                   <div className="aspect-[9/19] bg-gray-100 rounded-[2.5rem] border-[10px] border-gray-900 overflow-hidden shadow-2xl mt-12">
                      <img src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover grayscale" alt="Self Scan UX 1" />
                   </div>
                   <div className="aspect-[9/19] bg-gray-100 rounded-[2.5rem] border-[10px] border-gray-900 overflow-hidden shadow-2xl">
                      <img src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover grayscale" alt="Self Scan UX 2" />
                   </div>
                </div>
             </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 6. SEZIONE 02: MOBILE APP */}
      <section className="py-32 bg-gray-900 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <ScrollReveal>
             <div className="flex flex-col lg:flex-row-reverse items-center gap-20">
                <div className="w-full lg:w-1/2">
                   <div className="flex items-center gap-4 mb-8">
                     <span className="text-4xl font-serif italic text-gray-700">02</span>
                     <div className="h-px flex-1 bg-gray-800"></div>
                     <Smartphone className="text-[#007bff]" size={24} />
                   </div>
                   <h2 className="text-4xl font-serif mb-6 text-white">Mobile App: <br/> <span className="italic text-gray-500">L'esperienza oltre il negozio</span></h2>
                   <p className="text-lg text-gray-400 mb-8 leading-relaxed font-body">
                     La Mobile App estende il retail oltre i confini fisici, creando un canale diretto e personalizzato con il cliente, arricchendo l'engagement con il brand.
                   </p>
                   <div className="grid md:grid-cols-2 gap-8">
                      {[
                        { t: "Fedeltà", d: "Storico acquisti e programmi fedeltà." },
                        { t: "Promozioni", d: "Notifiche push e offerte mirate." },
                        { t: "Utilità", d: "Lista della spesa e store locator." }
                      ].map((box, i) => (
                        <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-sm">
                           <h4 className="font-product font-bold text-[10px] uppercase tracking-widest text-[#007bff] mb-3">{box.t}</h4>
                           <p className="text-sm text-gray-300 font-body">{box.d}</p>
                        </div>
                      ))}
                   </div>
                </div>
                <div className="w-full lg:w-1/2 relative">
                   <div className="aspect-[4/5] bg-gray-800 rounded-lg border border-gray-700 overflow-hidden shadow-inner flex items-center justify-center p-12">
                      <div className="grid grid-cols-2 gap-8 w-full max-w-sm">
                         <div className="aspect-[9/18] bg-black rounded-xl border border-gray-600 shadow-2xl rotate-[-5deg] overflow-hidden">
                           <img src="https://images.unsplash.com/photo-1512428559087-560ad5ceab42?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover opacity-50 grayscale" alt="App UX 1" />
                         </div>
                         <div className="aspect-[9/18] bg-black rounded-xl border border-gray-600 shadow-2xl rotate-[5deg] translate-y-8 overflow-hidden">
                           <img src="https://images.unsplash.com/photo-1556740758-90de374c12ad?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover opacity-50 grayscale" alt="App UX 2" />
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 7. STYLE GUIDE UNIFICATA */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-20">
               <h2 className="text-4xl font-serif mb-4">Style Guide Unificata</h2>
               <p className="text-gray-500 max-w-2xl mx-auto">Un linguaggio visivo coerente sviluppato per garantire un'esperienza utente fluida attraverso entrambi i moduli.</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-20">
               {/* Color Palette */}
               <div>
                  <h3 className="text-xs font-product font-bold uppercase tracking-widest text-gray-400 mb-8">Color Palette</h3>
                  <div className="flex flex-wrap gap-4">
                     {[
                       { hex: "#0056b3", name: "Primary Blue" },
                       { hex: "#007bff", name: "Action Blue" },
                       { hex: "#e9ecef", name: "Soft Grey" },
                       { hex: "#f8f9fa", name: "Off White" }
                     ].map((c, i) => (
                       <div key={i} className="group flex-1 min-w-[100px] text-center">
                          <div className="aspect-square rounded-full border border-gray-100 shadow-sm mb-4 transition-transform group-hover:scale-105" style={{ backgroundColor: c.hex }}></div>
                          <p className="text-[10px] font-product font-bold text-black">{c.hex}</p>
                          <p className="text-[8px] text-gray-400 uppercase tracking-tighter">{c.name}</p>
                       </div>
                     ))}
                  </div>
               </div>

               {/* Typography */}
               <div>
                  <h3 className="text-xs font-product font-bold uppercase tracking-widest text-gray-400 mb-8">Typography (Roboto Base)</h3>
                  <div className="space-y-6">
                     <div className="border-b border-gray-100 pb-4">
                        <p className="text-3xl font-bold font-product tracking-tight">Abc 123</p>
                        <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-2 font-product">Roboto Bold / Headings</p>
                     </div>
                     <div className="border-b border-gray-100 pb-4">
                        <p className="text-xl font-medium font-product">The retail future</p>
                        <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-2 font-product">Roboto Medium / Components</p>
                     </div>
                     <div>
                        <p className="text-sm font-product">Seamless shopping journey for every user.</p>
                        <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-2 font-product">Roboto Regular / Body</p>
                     </div>
                  </div>
               </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 8. CONCLUSIONE */}
      <section className="py-40 bg-gray-50 text-center">
        <ScrollReveal>
          <div className="max-w-3xl mx-auto px-6">
             <h2 className="text-5xl font-serif mb-8 italic">Conclusione</h2>
             <p className="text-xl text-gray-600 leading-relaxed font-body mb-16">
               Syntphony Retail Experience rappresenta un passo avanti nella digitalizzazione del retail. Un progetto che mette l'utente al centro, per un'esperienza di shopping senza soluzione di continuità.
             </p>
             <div className="flex flex-wrap justify-center gap-12 pt-12 border-t border-gray-200">
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Role</p>
                  <p className="text-sm font-bold">UX/UI Design</p>
               </div>
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Tools</p>
                  <p className="text-sm font-bold">Figma, Adobe Creative Suite</p>
               </div>
               <div>
                  <p className="text-[10px] font-product font-bold text-gray-400 uppercase tracking-widest mb-2">Year</p>
                  <p className="text-sm font-bold">2024</p>
               </div>
            </div>
          </div>
        </ScrollReveal>
      </section>

      {/* Footer CTA */}
      <footer className="py-40 bg-black text-white text-center">
         <ScrollReveal>
            <h2 className="text-4xl md:text-6xl font-serif mb-12">Interessato a <br/> soluzioni Retail?</h2>
            <button 
              onClick={onContact}
              className="px-12 py-5 bg-[#007bff] text-white rounded-full font-product font-bold uppercase tracking-widest hover:bg-[#0056b3] transition-all transform hover:scale-105"
            >
              Parliamone
            </button>
         </ScrollReveal>
      </footer>
    </div>
  );
};
