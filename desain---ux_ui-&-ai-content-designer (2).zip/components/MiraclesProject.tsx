
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Download, ArrowLeft, Share2, Calendar, User } from 'lucide-react';
import { GlobalBackButton } from './GlobalBackButton';
import { ScrollReveal } from './ScrollReveal';

export const MiraclesProject: React.FC<{ onBack: () => void, onContact: () => void }> = ({ onBack, onContact }) => {
  return (
    <div className="bg-white min-h-screen text-black font-body selection:bg-black selection:text-white pb-32">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-[120] bg-white/90 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-gray-100">
        <GlobalBackButton onClick={onBack} />
        <div className="text-[10px] font-product font-bold uppercase tracking-[0.3em] text-gray-400">
          Art Project / 2024
        </div>
      </div>

      {/* Hero Section */}
      <section className="pt-40 pb-20 px-6 max-w-5xl mx-auto">
        <ScrollReveal>
          <h1 className="text-6xl md:text-8xl font-serif italic mb-8 tracking-tighter">
            AI believe <br/> in miracles
          </h1>
          <div className="flex flex-wrap gap-8 items-center text-[10px] font-product font-bold uppercase tracking-widest text-gray-400 mb-16">
            <div className="flex items-center gap-2"><Calendar size={14} /> Released 2024</div>
            <div className="flex items-center gap-2"><User size={14} /> AI Content Director</div>
            <div className="flex items-center gap-2"><Share2 size={14} /> Experimental Art</div>
          </div>
        </ScrollReveal>

        {/* Poster / Locandina */}
        <ScrollReveal delay={0.2}>
          <div className="relative group overflow-hidden bg-gray-50 rounded-sm mb-24 shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=2000" 
              alt="AI believe in miracles Poster" 
              className="w-full h-auto grayscale group-hover:grayscale-0 transition-all duration-1000"
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="bg-white text-black px-6 py-2 text-[10px] font-product font-bold uppercase tracking-widest">Project Locandina</span>
            </div>
          </div>
        </ScrollReveal>

        {/* Video Section */}
        <ScrollReveal>
          <div className="mb-24">
            <div className="flex items-end justify-between mb-8 border-b border-gray-100 pb-4">
               <h2 className="text-3xl font-serif italic">The Short Film (3:00)</h2>
               <span className="font-mono text-xs text-gray-400 uppercase">Motion / AI Generation</span>
            </div>
            <div className="aspect-video bg-black rounded-sm relative flex items-center justify-center group cursor-pointer overflow-hidden">
               <img 
                 src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1600" 
                 className="absolute inset-0 w-full h-full object-cover opacity-40 grayscale group-hover:scale-105 transition-transform duration-1000" 
                 alt="Video Thumbnail"
               />
               <div className="relative z-10 flex flex-col items-center">
                 <div className="w-20 h-20 rounded-full border border-white/30 flex items-center justify-center backdrop-blur-md group-hover:bg-white group-hover:text-black transition-all mb-4">
                   <Play fill="currentColor" size={24} />
                 </div>
                 <p className="text-white text-[10px] font-product font-bold uppercase tracking-[0.4em]">Play Sequence</p>
               </div>
            </div>
            <p className="mt-8 text-gray-500 font-body text-lg leading-relaxed italic text-center max-w-2xl mx-auto">
              "Un viaggio onirico dove i confini tra realtà e generazione algoritmica sfumano nel miracolo del quotidiano."
            </p>
          </div>
        </ScrollReveal>

        {/* Presentation Download */}
        <ScrollReveal>
          <div className="bg-gray-50 p-12 md:p-20 text-center rounded-sm">
            <h3 className="text-4xl font-serif mb-8">Concept Presentation</h3>
            <p className="text-gray-600 font-body mb-12 max-w-xl mx-auto">
              Approfondisci il processo creativo, i prompt engineering e le scelte artistiche dietro "AI believe in miracles".
            </p>
            <button className="inline-flex items-center gap-4 bg-black text-white px-12 py-5 rounded-full font-product font-bold uppercase tracking-widest hover:bg-gray-800 transition-all transform hover:scale-105">
              <Download size={20} /> Download PDF (12MB)
            </button>
          </div>
        </ScrollReveal>
      </section>

      {/* Footer */}
      <footer className="mt-40 py-40 border-t border-gray-100 text-center">
        <ScrollReveal>
          <h2 className="text-4xl font-serif mb-12">Interessato a una <br/> collaborazione artistica?</h2>
          <button onClick={onContact} className="px-12 py-5 bg-black text-white rounded-full font-product font-bold uppercase tracking-widest hover:bg-gray-800 transition-all">
            Parliamone
          </button>
        </ScrollReveal>
      </footer>
    </div>
  );
};
