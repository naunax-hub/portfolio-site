
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Database, 
  UploadCloud, 
  FileCode, 
  Terminal, 
  HardDrive, 
  Eye, 
  RefreshCw, 
  Lock,
  Cpu,
  Globe,
  Settings,
  Trash2,
  CheckCircle,
  Activity
} from 'lucide-react';

export interface Asset {
  id: string;
  name: string;
  type: 'image' | 'video';
  url: string;
  category: string;
  status: 'published' | 'staged';
  timestamp: string;
}

export const ExternalAssetEngine: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [assets, setAssets] = useState<Asset[]>([
    { id: '01', name: 'hero_vortex.mp4', type: 'video', url: 'https://video.com/1', category: 'UX Hero', status: 'published', timestamp: '2024-05-20 14:30' },
    { id: '02', name: 'diesel_redesign_main.jpg', type: 'image', url: 'https://img.com/2', category: 'Portfolio', status: 'published', timestamp: '2024-05-21 09:12' },
    { id: '03', name: 'digital_content_pinterest.jpg', type: 'image', url: 'https://img.com/3', category: 'Digital Content', status: 'published', timestamp: '2024-05-22 11:45' },
  ]);

  const triggerSync = () => {
    setIsSyncing(true);
    setTimeout(() => setIsSyncing(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#00ff41] font-mono p-4 md:p-10 selection:bg-[#00ff41] selection:text-black">
      {/* Terminal Header */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 border-b border-[#00ff41]/20 pb-8 gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Database className="animate-pulse" size={24} />
            <h1 className="text-xl font-bold tracking-tighter uppercase">DesAIn_External_Engine_v1.0</h1>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-[#00ff41]/60 uppercase tracking-widest">
            <span className="flex items-center gap-1"><Globe size={10}/> Server: EU-Milan-1</span>
            <span className="flex items-center gap-1"><Cpu size={10}/> CPU: 0.4%</span>
            <span className="flex items-center gap-1"><Activity size={10}/> Latency: 14ms</span>
          </div>
        </div>
        
        <div className="flex gap-4">
          <button 
            onClick={triggerSync}
            className={`flex items-center gap-2 px-4 py-2 border border-[#00ff41] text-[10px] font-bold uppercase hover:bg-[#00ff41] hover:text-black transition-all ${isSyncing ? 'animate-pulse opacity-50' : ''}`}
          >
            <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
            {isSyncing ? 'Syncing...' : 'Sync to Site'}
          </button>
          <button 
            onClick={onExit}
            className="flex items-center gap-2 px-4 py-2 bg-[#00ff41] text-black text-[10px] font-bold uppercase hover:bg-white transition-all"
          >
            <Lock size={14} /> Exit System
          </button>
        </div>
      </header>

      <div className="grid lg:grid-cols-12 gap-10">
        {/* Left: Upload & JSON Feed */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-[#111] border border-[#00ff41]/20 p-6 rounded-sm">
            <h2 className="text-xs font-bold uppercase mb-6 flex items-center gap-2">
              <UploadCloud size={16} /> Asset Injection
            </h2>
            <div className="border-2 border-dashed border-[#00ff41]/20 rounded-sm p-10 text-center hover:border-[#00ff41]/50 transition-all cursor-pointer group">
              <Terminal size={32} className="mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <p className="text-[10px] uppercase tracking-[0.2em] leading-relaxed">
                Drop files to upload<br/>
                <span className="text-[#00ff41]/40">JPG, PNG, MP4, WEBP</span>
              </p>
            </div>
          </div>

          <div className="bg-[#111] border border-[#00ff41]/20 p-6 rounded-sm">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xs font-bold uppercase flex items-center gap-2">
                <FileCode size={16} /> JSON Response
              </h2>
              <button className="text-[8px] hover:underline">COPY ENDPOINT</button>
            </div>
            <pre className="text-[10px] text-[#00ff41]/40 leading-relaxed overflow-x-auto">
{`{
  "system": "DesAIn_Database",
  "assets_count": ${assets.length},
  "status": "ready",
  "last_sync": "${new Date().toISOString()}",
  "cdn_edge": "enabled"
}`}
            </pre>
          </div>
        </div>

        {/* Right: Database Content Table */}
        <div className="lg:col-span-8">
          <div className="bg-[#111] border border-[#00ff41]/20 rounded-sm overflow-hidden">
            <div className="p-6 border-b border-[#00ff41]/10 flex justify-between items-center">
               <h2 className="text-xs font-bold uppercase flex items-center gap-2">
                <HardDrive size={16} /> Asset Repository
              </h2>
              <div className="flex gap-4">
                <div className="bg-black border border-[#00ff41]/20 px-3 py-1 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#00ff41] animate-pulse"></div>
                  <span className="text-[8px]">LIVE CONNECTION</span>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-[10px]">
                <thead className="bg-black/50 border-b border-[#00ff41]/10">
                  <tr>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50">ID</th>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50">Name</th>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50">Path</th>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50">Binding</th>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50">Status</th>
                    <th className="px-6 py-4 uppercase font-bold tracking-widest text-[#00ff41]/50 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#00ff41]/5">
                  {assets.map((asset) => (
                    <tr key={asset.id} className="hover:bg-[#00ff41]/5 transition-colors group">
                      <td className="px-6 py-5 font-bold">#{asset.id}</td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-3">
                          {asset.type === 'video' ? <Activity size={12}/> : <Eye size={12}/>}
                          {asset.name}
                        </div>
                      </td>
                      <td className="px-6 py-5 opacity-40">/media/v1/{asset.id}/{asset.type}</td>
                      <td className="px-6 py-5">
                         <span className="bg-black px-2 py-1 border border-[#00ff41]/20">{asset.category}</span>
                      </td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-2">
                           <CheckCircle size={10} />
                           {asset.status.toUpperCase()}
                        </div>
                      </td>
                      <td className="px-6 py-5 text-right">
                        <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="hover:text-white"><Settings size={14}/></button>
                          <button className="hover:text-red-500"><Trash2 size={14}/></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="p-4 bg-black/30 border-t border-[#00ff41]/10 text-center">
              <p className="text-[8px] opacity-30 italic">End of line. Database listening on port 8080.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
