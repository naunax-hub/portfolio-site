import React from 'react';
import { motion } from 'framer-motion';

export const HandDrawnHero = () => {
  // Animation config for drawing effect
  const draw = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: (i: number) => ({
      pathLength: 1,
      opacity: 1,
      transition: {
        pathLength: { delay: i * 0.15, type: "spring", duration: 2, bounce: 0 },
        opacity: { delay: i * 0.15, duration: 0.01 }
      }
    })
  };

  return (
    <div className="w-full h-full flex items-center justify-center bg-transparent p-4">
        <svg viewBox="0 0 800 600" className="w-full h-full max-w-2xl overflow-visible stroke-gray-800 fill-none stroke-[1.5] stroke-linecap-round stroke-linejoin-round">
            <motion.g
                initial="hidden"
                animate="visible"
                style={{ rotate: -1.5 }} // Slight organic tilt
            >
                {/* --- BROWSER WINDOW FRAME --- */}
                <motion.rect 
                    x="50" y="50" width="700" height="500" rx="15" 
                    custom={0} variants={draw} 
                />
                {/* Address Bar */}
                <motion.line x1="50" y1="100" x2="750" y2="100" custom={0.5} variants={draw} />
                <motion.circle cx="85" cy="75" r="6" custom={0.6} variants={draw} />
                <motion.circle cx="110" cy="75" r="6" custom={0.7} variants={draw} />
                <motion.circle cx="135" cy="75" r="6" custom={0.8} variants={draw} />
                
                {/* --- HEADER --- */}
                {/* Logo Placeholder */}
                <motion.path d="M100 145 H200" custom={1} variants={draw} strokeWidth="4" />
                {/* Nav Links Placeholder */}
                <motion.path d="M520 145 H570 M600 145 H650 M680 145 H720" custom={1.2} variants={draw} />

                {/* --- HERO SECTION --- */}
                {/* Main Headline Lines */}
                <motion.path d="M100 220 H480" custom={2} variants={draw} strokeWidth="6" />
                <motion.path d="M100 260 H380" custom={2.2} variants={draw} strokeWidth="6" />
                
                {/* Paragraph Lines */}
                <motion.path d="M100 310 H420 M100 335 H450 M100 360 H320" custom={2.5} variants={draw} strokeWidth="1.5" />
                
                {/* CTA Button */}
                <motion.rect x="100" y="410" width="140" height="45" rx="22.5" custom={3} variants={draw} />
                <motion.path d="M135 432.5 H205" custom={3.2} variants={draw} />

                {/* --- IMAGE PLACEHOLDER (Right side) --- */}
                <motion.rect x="520" y="210" width="180" height="230" rx="8" custom={3.5} variants={draw} />
                <motion.line x1="520" y1="210" x2="700" y2="440" custom={3.8} variants={draw} opacity="0.3" />
                <motion.line x1="520" y1="440" x2="700" y2="210" custom={3.8} variants={draw} opacity="0.3" />

                {/* --- SMALL UI DETAILS (Bottom) --- */}
                <motion.circle cx="100" cy="510" r="10" custom={4.5} variants={draw} />
                <motion.circle cx="140" cy="510" r="10" custom={4.6} variants={draw} />
                <motion.circle cx="180" cy="510" r="10" custom={4.7} variants={draw} />
            </motion.g>
        </svg>
    </div>
  );
};
