import React from 'react';
import { motion } from 'framer-motion';

interface ScrollRevealProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  width?: 'full' | 'fit';
}

export const ScrollReveal: React.FC<ScrollRevealProps> = ({ 
  children, 
  delay = 0, 
  className = "",
  width = "full" 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ 
        duration: 0.45, 
        ease: "easeOut",
        delay: delay 
      }}
      className={`${width === 'full' ? 'w-full' : 'w-fit'} ${className}`}
    >
      {children}
    </motion.div>
  );
};