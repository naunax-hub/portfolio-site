import React from 'react';
import { ArrowLeft } from 'lucide-react';

export const GlobalBackButton = ({ onClick }: { onClick: () => void }) => (
  <button 
    onClick={onClick} 
    className="flex items-center gap-2 text-black font-medium hover:opacity-80 transition-opacity text-sm tracking-wide uppercase group font-body"
  >
    <ArrowLeft className="w-5 h-5" /> BACK
  </button>
);