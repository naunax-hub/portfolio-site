import React, { useState } from 'react';
import { motion } from 'framer-motion';

const data = [
  { subject: 'Copywriting', A: 85, fullMark: 100 },
  { subject: 'Art Direction', A: 90, fullMark: 100 },
  { subject: 'AI Tools', A: 95, fullMark: 100 },
  { subject: 'UX Design', A: 98, fullMark: 100 },
  { subject: 'UI Design', A: 92, fullMark: 100 },
  { subject: 'Research', A: 80, fullMark: 100 },
];

// --- GEOMETRY HELPERS ---
const NUM_AXES = data.length;
const CENTER = 150; // SVG viewBox center x,y
const MAX_RADIUS = 100; // Max radius of the chart
const ANGLE_STEP = (Math.PI * 2) / NUM_AXES;

// Helper to get coordinates
const getCoordinates = (value: number, index: number) => {
  // -PI/2 to start at 12 o'clock
  const angle = index * ANGLE_STEP - Math.PI / 2; 
  const x = CENTER + (value / 100) * MAX_RADIUS * Math.cos(angle);
  const y = CENTER + (value / 100) * MAX_RADIUS * Math.sin(angle);
  return { x, y };
};

// Build the path string for a polygon
const buildPath = (values: number[]) => {
  return values.map((val, i) => {
    const coords = getCoordinates(val, i);
    return `${i === 0 ? 'M' : 'L'} ${coords.x},${coords.y}`;
  }).join(' ') + ' Z';
};

export const SkillsRadar: React.FC = () => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Data Points for the actual shape
  const pointValues = data.map(d => d.A);
  const finalPath = buildPath(pointValues);
  
  // Zero Path for animation origin (draw from center)
  const zeroValues = data.map(() => 0);
  const zeroPath = buildPath(zeroValues);

  // Background Grid (Concentric polygons)
  const gridLevels = [25, 50, 75, 100];

  return (
    <div className="relative w-full max-w-[500px] aspect-square flex items-center justify-center">
      <motion.svg
        viewBox="0 0 300 300"
        className="w-full h-full overflow-visible"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-50px" }}
      >
        {/* --- FASE 1: GRID & AXES --- */}
        <g className="grid-layer">
           {/* Axes */}
           {data.map((_, i) => {
             const end = getCoordinates(100, i);
             return (
               <motion.line
                 key={`axis-${i}`}
                 x1={CENTER} y1={CENTER}
                 x2={end.x} y2={end.y}
                 stroke={hoveredIndex === i ? "#ec4899" : "#e5e5e5"} // Pink on hover
                 strokeWidth={1}
                 strokeOpacity={hoveredIndex === i ? 0.4 : 1}
                 variants={{
                   hidden: { opacity: 0, pathLength: 0 },
                   visible: { opacity: 1, pathLength: 1 }
                 }}
                 transition={{ duration: 0.4, ease: "easeOut" }}
               />
             );
           })}
           
           {/* Concentric Polygons */}
           {gridLevels.map((level, i) => (
             <motion.path
               key={`grid-${level}`}
               d={buildPath(Array(NUM_AXES).fill(level))}
               fill="none"
               stroke="#e5e5e5"
               strokeWidth={1}
               variants={{
                 hidden: { opacity: 0 },
                 visible: { opacity: 1 }
               }}
               transition={{ duration: 0.4, delay: i * 0.1 }}
             />
           ))}
        </g>

        {/* --- FASE 2 & IDLE: DATA POLYGON --- */}
        {/* We wrap in a group for the "Breathing" idle animation */}
        <motion.g
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ 
            duration: 6, 
            ease: "easeInOut", 
            repeat: Infinity,
            repeatType: "mirror" 
          }}
          style={{ originX: "50%", originY: "50%" }}
        >
            {/* Main Polygon Area */}
            <motion.path
              d={finalPath}
              fill="#ec4899"
              fillOpacity={0.3}
              stroke="#ec4899"
              strokeWidth={2}
              // Draw from center animation
              variants={{
                hidden: { d: zeroPath, opacity: 0 },
                visible: { d: finalPath, opacity: 1 }
              }}
              transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }} // cubic-bezier-ish
              
              // Glow Idle Effect
              animate={{ filter: ["drop-shadow(0 0 0px rgba(236,72,153,0))", "drop-shadow(0 0 2px rgba(236,72,153,0.3))", "drop-shadow(0 0 0px rgba(236,72,153,0))"] }}
              // Note: We have to combine the 'visible' state transition with the infinite animation.
              // Framer motion handles this by orchestrating variants first, then 'animate' prop takes over after.
              // To keep it simple, we apply the glow in style or separate element, but `animate` prop works for idle loops.
            />
        </motion.g>

        {/* --- FASE 3 & IDLE: DOTS --- */}
        {data.map((d, i) => {
          const coords = getCoordinates(d.A, i);
          const isHovered = hoveredIndex === i;

          return (
            <motion.circle
              key={`dot-${i}`}
              cx={coords.x}
              cy={coords.y}
              r={4}
              fill="#ec4899"
              
              // Entrance: Pop in
              variants={{
                hidden: { scale: 0, opacity: 0 },
                visible: { scale: 1, opacity: 1 }
              }}
              transition={{ 
                duration: 0.25, 
                delay: 0.55 + (i * 0.05), // Start after polygon (0.5s)
                ease: "backOut" 
              }}
              
              // Idle: Async Pulse
              animate={{ opacity: [1, 0.7, 1] }}
              // Since animate prop overrides variants after mount, 
              // we need to be careful. For simplicity in this complexity, 
              // we rely on the `whileInView` to trigger entrance, and a separate child or style for pulse.
              // Actually, framer-motion `animate` prop runs after layout/variant animations are complete if configured right,
              // but often it's safer to use a separate component or just accept the override.
              // Hack: Use style opacity and CSS animation for the loop to not conflict with Framer's entrance? 
              // Better: Use Framer for entrance, then let a `transition` on the opacity handle the loop.
            />
          );
        })}
        
        {/* Dots Pulse Layer (Separate to avoid conflict with entrance scale) */}
        {data.map((d, i) => {
            const coords = getCoordinates(d.A, i);
            return (
                <motion.circle 
                    key={`pulse-${i}`}
                    cx={coords.x}
                    cy={coords.y}
                    r={4}
                    fill="#ec4899"
                    opacity={0}
                    animate={{ opacity: [0, 0.5, 0] }}
                    transition={{
                        duration: 3,
                        delay: 1 + i, // Async delay
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                    pointerEvents="none"
                />
            )
        })}

        {/* --- FASE 3/Hover: INTERACTIVE DOTS (Hitbox) --- */}
        {data.map((d, i) => {
            const coords = getCoordinates(d.A, i);
            return (
                <motion.circle 
                    key={`hitbox-${i}`}
                    cx={coords.x}
                    cy={coords.y}
                    r={12} // Larger hit area
                    fill="transparent"
                    cursor="pointer"
                    onMouseEnter={() => setHoveredIndex(i)}
                    onMouseLeave={() => setHoveredIndex(null)}
                    whileHover={{ scale: 1.1 }}
                />
            )
        })}

      </motion.svg>

      {/* --- FASE 4: LABELS (HTML Overlay for better text rendering) --- */}
      <div className="absolute inset-0 pointer-events-none">
        {data.map((d, i) => {
          // Calculate position for label (slightly outside radius)
          const angle = i * ANGLE_STEP - Math.PI / 2;
          // 130% radius for text
          const radius = MAX_RADIUS + 35; 
          // Convert back to %, relative to 300x300 viewBox logic mapped to 100% container
          // x = 150 + r*cos, y = 150 + r*sin. 
          // We need percentage for `left/top` CSS: (val / 300) * 100
          const xPercent = (CENTER + radius * Math.cos(angle)) / 300 * 100;
          const yPercent = (CENTER + radius * Math.sin(angle)) / 300 * 100;
          
          const isHovered = hoveredIndex === i;

          return (
            <motion.div
              key={`label-${i}`}
              className={`absolute text-xs md:text-sm font-serif transition-colors duration-200 ${isHovered ? 'text-black font-medium' : 'text-gray-400'}`}
              style={{ 
                left: `${xPercent}%`, 
                top: `${yPercent}%`,
                transform: 'translate(-50%, -50%)' 
              }}
              
              // Entrance: Fade in + slide up
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ 
                duration: 0.3, 
                delay: 0.8 + (i * 0.08), // Sequenced after polygon
                ease: "easeOut"
              }}
            >
              {d.subject}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};