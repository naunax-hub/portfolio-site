
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Lightbulb, Monitor, Rocket, Search, Target, ChevronDown, Play, Filter, ChevronRight, Share2, Instagram as InstaIcon, PinIcon, Database, Terminal } from 'lucide-react';
import { ScrollReveal } from './components/ScrollReveal';
import { SkillsRadar } from './components/RadarChart';
import { ContactPage } from './components/ContactPage';
import { GlobalBackButton } from './components/GlobalBackButton';
import { HandDrawnHero } from './components/HandDrawnHero';
import { DieselProject } from './components/DieselProject';
import { MiraclesProject } from './components/MiraclesProject';
import { ExternalAssetEngine } from './components/ExternalAssetEngine';
import { RestaurantProject } from './components/RestaurantProject';
import { RetailProject } from './components/RetailProject';

// --- SHARED GLOBAL COMPONENTS ---

const GlobalHeader = ({ 
  currentView, 
  setView 
}: { 
  currentView: string, 
  setView: (view: string) => void 
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleContactClick = () => {
    setView('contact');
  };

  const handleProjectClick = (action: () => void) => {
    action();
    setIsDropdownOpen(false);
  };

  const projects = [
    { 
      title: "Restaurant Experience", 
      category: "UX/UI Design", 
      action: () => setView('restaurant') 
    },
    { 
      title: "Retail Experience", 
      category: "UX/UI Design", 
      action: () => setView('retail') 
    },
    { 
      title: "Diesel Redesign", 
      category: "AI Content Design", 
      action: () => setView('diesel')
    },
    { 
      title: "Art Projects", 
      category: "Visual Art", 
      action: () => setView('artprojects')
    }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 h-20 bg-white/80 backdrop-blur-md shadow-sm z-[100] px-6 md:px-12 flex items-center justify-between transition-all duration-300">
       <div 
         className="text-2xl font-bold font-serif text-black cursor-pointer"
         onClick={() => setView('home')}
       >
         DesAIn
       </div>

       <nav className="flex items-center gap-8 font-body relative">
          <div className="relative">
             <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center gap-2 text-sm font-medium text-black uppercase tracking-wider hover:opacity-70 transition-opacity"
             >
                Projects <ChevronDown size={14} className={`transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
             </button>

             <AnimatePresence>
               {isDropdownOpen && (
                 <motion.div
                   initial={{ opacity: 0, y: 10 }}
                   animate={{ opacity: 1, y: 0 }}
                   exit={{ opacity: 0, y: 10 }}
                   className="absolute top-full right-0 mt-6 w-80 bg-white shadow-xl rounded-lg border border-gray-100 overflow-hidden py-2"
                 >
                    {projects.map((p, i) => (
                       <div 
                         key={i} 
                         onClick={() => handleProjectClick(p.action)}
                         className="px-6 py-4 hover:bg-gray-50 cursor-pointer border-b border-gray-50 last:border-0 transition-colors"
                       >
                          <h4 className="font-serif text-lg text-black mb-1">{p.title}</h4>
                          <span className="text-xs font-medium text-gray-400 uppercase tracking-widest">{p.category}</span>
                       </div>
                    ))}
                 </motion.div>
               )}
             </AnimatePresence>
          </div>

          <button 
             onClick={handleContactClick}
             className="text-sm font-medium text-black uppercase tracking-wider hover:opacity-70 transition-opacity"
          >
             Contact
          </button>
       </nav>
    </header>
  );
};

// --- HOME COMPONENTS ---

const Hero = ({ onContact }: { onContact: () => void }) => (
  <section className="min-h-screen flex flex-col md:flex-row items-center justify-center px-6 md:px-20 py-20 gap-12 overflow-hidden pt-32">
    <div className="w-full md:w-1/2 flex flex-col items-start space-y-8 z-10">
      <motion.span 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.2, duration: 0.5 }}
        className="text-sm md:text-base font-body italic text-gray-500 tracking-wide"
      >
        Hello, I'm Laura Memmola
      </motion.span>
      <motion.h1 
        initial={{ opacity: 0, y: 10 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ delay: 0.35, duration: 0.6 }}
        className="text-5xl md:text-7xl font-serif font-medium leading-tight text-gray-900"
      >
        UX/UI & <br/> 
        <span className="text-gray-400 italic">AI Content</span> <br/>
        Designer
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 10 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ delay: 0.5, duration: 0.6 }}
        className="font-body text-lg md:text-xl text-gray-600 leading-relaxed max-w-md"
      >
        Crafting digital experiences where human empathy meets artificial intelligence. 
        Designing the future, one pixel at a time.
      </motion.p>
      <motion.button 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.7 }}
        whileHover={{ scale: 1.03, backgroundColor: '#111' }}
        onClick={onContact}
        className="bg-black text-white px-8 py-3 rounded-md text-sm font-medium tracking-wide transition-all duration-300 font-body"
      >
        Contact Me
      </motion.button>
    </div>
    <div className="w-full md:w-1/2 h-[50vh] md:h-auto flex items-center justify-center relative">
       <motion.div 
         initial={{ opacity: 0, scale: 0.95 }}
         animate={{ opacity: 1, scale: 1 }}
         transition={{ duration: 0.8, ease: "easeOut" }}
         className="relative w-full max-w-lg aspect-[4/3]"
       >
         <HandDrawnHero />
       </motion.div>
    </div>
  </section>
);

const Portfolio = ({ 
  setView
}: { 
  setView: (v: string) => void
}) => (
  <section className="py-32 bg-white">
    <div className="container mx-auto px-6">
      {/* Section 01: UX/UI */}
      <div className="mb-32">
        <ScrollReveal>
          <div className="flex items-end justify-between mb-16 border-b border-black pb-4">
             <h2 className="text-4xl md:text-5xl font-serif">UX/UI Design</h2>
             <span className="font-mono text-sm text-gray-400">01</span>
          </div>
        </ScrollReveal>
        <div className="space-y-32">
           {/* Restaurant */}
           <div onClick={() => setView('restaurant')} className="group cursor-pointer">
             <ScrollReveal width="full">
               <div className="grid md:grid-cols-2 gap-12 items-center">
                 <div className="order-2 md:order-1">
                    <span className="font-mono text-xs text-gray-400 mb-4 block uppercase">White Label Product</span>
                    <h3 className="text-3xl md:text-4xl font-serif mb-6 group-hover:underline decoration-1 underline-offset-4">Restaurant Experience</h3>
                    <p className="text-gray-600 font-body leading-relaxed max-w-md mb-8">A comprehensive ecosystem for restaurant management, optimizing workflows from kitchen to front-of-house.</p>
                 </div>
                 <div className="order-1 md:order-2 bg-gray-50 aspect-[4/3] overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-700">
                    <img src="https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?auto=format&fit=crop&q=80&w=800" className="object-cover w-full h-full transform group-hover:scale-105 transition-all" alt="Restaurant" />
                 </div>
               </div>
             </ScrollReveal>
           </div>
           {/* Retail */}
           <div onClick={() => setView('retail')} className="group cursor-pointer">
             <ScrollReveal width="full">
               <div className="grid md:grid-cols-2 gap-12 items-center">
                 <div className="order-2">
                    <span className="font-mono text-xs text-gray-400 mb-4 block uppercase">Omnichannel Strategy</span>
                    <h3 className="text-3xl md:text-4xl font-serif mb-6 group-hover:underline decoration-1 underline-offset-4">Retail Experience</h3>
                    <p className="text-gray-600 font-body leading-relaxed max-w-md mb-8">Revolutionizing the shopping journey by blending self-scanning autonomy with mobile versatility.</p>
                 </div>
                 <div className="order-1 bg-gray-50 aspect-[4/3] overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-700">
                    <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=800" className="object-cover w-full h-full transform group-hover:scale-105 transition-all" alt="Retail" />
                 </div>
               </div>
             </ScrollReveal>
           </div>
        </div>
      </div>

      {/* Section 02: AI Content */}
      <div className="mb-32 pt-20">
         <ScrollReveal>
          <div className="flex items-end justify-between mb-16 border-b border-black pb-4">
             <h2 className="text-4xl md:text-5xl font-serif">AI Content Design</h2>
             <span className="font-mono text-sm text-gray-400">02</span>
          </div>
        </ScrollReveal>
        <ScrollReveal>
           <div onClick={() => setView('diesel')} className="bg-gray-50 p-12 md:p-24 text-center cursor-pointer hover:bg-gray-100 transition-colors">
              <span className="font-mono text-xs text-gray-400 mb-6 block uppercase tracking-widest tracking-[0.3em]">Experimental Redesign</span>
              <h3 className="text-4xl md:text-6xl font-serif mb-8 italic">Diesel Redesign</h3>
              <p className="max-w-2xl mx-auto text-gray-600 font-body text-lg leading-relaxed">Leveraging generative AI to explore new visual languages and narrative structures for modern luxury brands.</p>
           </div>
        </ScrollReveal>
      </div>

      {/* Section 03: Art Projects */}
      <div id="art-projects" className="pt-20">
         <ScrollReveal>
          <div className="flex items-end justify-between mb-16 border-b border-black pb-4">
             <h2 className="text-4xl md:text-5xl font-serif">Art Projects</h2>
             <span className="font-mono text-sm text-gray-400">03</span>
          </div>
        </ScrollReveal>
        <div className="space-y-24">
           {[
             { title: "AI believe in miracles", img: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=800", type: 'view', target: 'miracles' },
             { title: "Animae.ai", img: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800", type: 'link', target: 'https://www.instagram.com/animae.ai/' },
             { title: "Digital Content", img: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800", type: 'link', target: 'https://pin.it/7cHpeOJQc' }
           ].map((art, i) => (
              <ScrollReveal key={i} width="full">
                 <div 
                   onClick={() => art.type === 'link' ? window.open(art.target, '_blank') : setView(art.target)} 
                   className="group flex flex-col md:flex-row items-center gap-12 cursor-pointer"
                 >
                    <div className="w-full md:w-1/2 aspect-[3/2] overflow-hidden rounded-sm bg-gray-50">
                       <img src={art.img} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105" alt={art.title}/>
                    </div>
                    <div className="w-full md:w-1/2 text-center md:text-left">
                       <span className="font-mono text-xs text-gray-400 mb-4 block">0{i+1}</span>
                       <h3 className="text-3xl font-serif italic group-hover:not-italic transition-all duration-300 flex items-center justify-center md:justify-start gap-4">
                         {art.title} 
                         {art.type === 'link' && <Share2 size={16} className="text-gray-300" />}
                       </h3>
                    </div>
                 </div>
              </ScrollReveal>
           ))}
        </div>
      </div>
    </div>
  </section>
);

const Methodology = () => (
  <section className="py-24 bg-black text-white">
    <div className="container mx-auto px-6">
       <ScrollReveal>
         <h2 className="text-3xl md:text-4xl font-serif mb-16 text-center text-white">Methodology</h2>
       </ScrollReveal>
       <div className="grid md:grid-cols-3 gap-12">
          {[
            { phase: "01", title: "Listen", desc: "Understanding the core needs and objectives through deep active listening.", icon: <Brain className="w-6 h-6"/> },
            { phase: "02", title: "Research", desc: "Analyzing market trends, user behaviors, and competitive landscapes.", icon: <Search className="w-6 h-6"/> },
            { phase: "03", title: "Strategy", desc: "Defining clear pathways and strategic frameworks for project success.", icon: <Target className="w-6 h-6"/> },
            { phase: "04", title: "Ideation", desc: "Generating innovative concepts and creative solutions.", icon: <Lightbulb className="w-6 h-6"/> },
            { phase: "05", title: "Prototyping", desc: "Building tangible models to test and refine interactions.", icon: <Monitor className="w-6 h-6"/> },
            { phase: "06", title: "Delivery", desc: "Ensuring pixel-perfect implementation and final launch.", icon: <Rocket className="w-6 h-6"/> }
          ].map((item, i) => (
             <ScrollReveal key={i} delay={i * 0.1}>
                <div className="group border-t border-gray-800 pt-8 hover:border-white transition-colors duration-500">
                   <div className="flex justify-between items-start mb-4">
                      <span className="text-sm font-mono text-gray-500 group-hover:text-white transition-colors">{item.phase}</span>
                      <div className="text-gray-500 group-hover:text-white transition-colors">{item.icon}</div>
                   </div>
                   <h3 className="text-xl font-serif font-medium mb-3">{item.title}</h3>
                   <p className="text-gray-400 font-body leading-relaxed">{item.desc}</p>
                </div>
             </ScrollReveal>
          ))}
       </div>
    </div>
  </section>
);

const Footer = ({ 
  onContact,
  onOpenEngine
}: { 
  onContact: () => void,
  onOpenEngine: () => void
}) => (
  <footer id="contact-footer" className="bg-white pt-32 pb-12 border-t border-gray-100">
    <div className="container mx-auto px-6 text-center">
      <ScrollReveal>
         <h2 className="text-4xl md:text-6xl font-serif mb-12 max-w-4xl mx-auto leading-tight">
           Let's connect and share ideas and projects.
         </h2>
         <button onClick={onContact} className="inline-block bg-black text-white px-10 py-4 rounded-full text-lg font-medium tracking-wide hover:bg-gray-800 transition-colors font-body mb-24">
           Contact Me
         </button>
      </ScrollReveal>
      <div className="flex flex-col md:flex-row justify-between items-center text-sm font-mono text-gray-400 pt-12 border-t border-gray-100">
         <p>© {new Date().getFullYear()} DesAIn — Laura Memmola</p>
         <div className="flex gap-8 mt-4 md:mt-0 items-center">
            {/* Technical Entry Point for Database */}
            <button 
              onClick={onOpenEngine}
              className="group flex items-center gap-2 text-[10px] uppercase tracking-widest hover:text-black transition-colors"
            >
              <Terminal size={12} className="group-hover:animate-pulse" /> engine.access
            </button>
            <a href="https://www.linkedin.com/in/laura-memmola/" target="_blank" rel="noopener noreferrer" className="hover:text-black transition-colors">LinkedIn</a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-black transition-colors">Instagram</a>
         </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  const [view, setView] = useState('home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  const handleContact = () => setView('contact');

  return (
    <div className="min-h-screen bg-white text-black font-body">
      {view !== 'engine' && <GlobalHeader currentView={view} setView={setView} />}
      
      <main className={view === 'engine' ? '' : 'pt-20'}>
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <Hero onContact={handleContact} />
              <section className="py-12 border-t border-gray-100">
                <div className="container mx-auto px-6 flex flex-col items-center">
                    <span className="text-xs font-semibold tracking-[0.2em] text-gray-400 mb-8 uppercase font-body">Trusted By</span>
                    <div className="flex flex-wrap justify-center gap-x-12 gap-y-8 opacity-70 grayscale">
                      {["Fastweb", "Sky", "Il Sole 24 Ore", "Vespa", "Piaggio", "Esselunga", "Illy Caffè", "Costa Crociere", "UniCoop", "Leroy Merlin"].map(brand => (
                        <span key={brand} className="text-xl md:text-2xl font-serif text-gray-400 hover:text-gray-800 transition-colors cursor-default">{brand}</span>
                      ))}
                    </div>
                </div>
              </section>
              <section className="py-24 bg-white">
                <div className="container mx-auto px-6">
                  <div className="flex flex-col items-center justify-center">
                    <ScrollReveal><h2 className="text-3xl md:text-4xl font-serif mb-16 text-center">Skills</h2></ScrollReveal>
                    <div className="w-full flex justify-center"><SkillsRadar /></div>
                  </div>
                </div>
              </section>
              <Methodology />
              <Portfolio setView={setView} />
              <Footer onContact={handleContact} onOpenEngine={() => setView('engine')} />
            </motion.div>
          )}
          
          {view === 'contact' && (
            <motion.div key="contact" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ContactPage onBack={() => setView('home')} />
            </motion.div>
          )}

          {view === 'engine' && (
            <motion.div key="engine" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ExternalAssetEngine onExit={() => setView('home')} />
            </motion.div>
          )}

          {view === 'diesel' && (
            <motion.div key="diesel" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <DieselProject onBack={() => setView('home')} onContact={handleContact} />
            </motion.div>
          )}

          {view === 'miracles' && (
            <motion.div key="miracles" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <MiraclesProject onBack={() => setView('home')} onContact={handleContact} />
            </motion.div>
          )}

          {view === 'restaurant' && (
            <motion.div key="restaurant" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <RestaurantProject onBack={() => setView('home')} onContact={handleContact} />
            </motion.div>
          )}

          {view === 'retail' && (
            <motion.div key="retail" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <RetailProject onBack={() => setView('home')} onContact={handleContact} />
            </motion.div>
          )}

          {view === 'artprojects' && (
            <motion.div key="artprojects" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ArtProjectsNode onBack={() => setView('home')} setView={setView} onContact={handleContact} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

const ArtProjectsNode = ({ onBack, setView, onContact }: any) => (
  <div className="p-12 md:p-32 bg-white min-h-screen">
    <GlobalBackButton onClick={onBack} />
    <h1 className="text-5xl md:text-7xl font-serif mt-12 mb-20 italic">Art Projects</h1>
    <div className="grid md:grid-cols-2 gap-12">
        <div onClick={() => setView('miracles')} className="group cursor-pointer">
           <div className="aspect-[4/3] bg-gray-50 mb-6 overflow-hidden">
              <img src="https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="Miracles" />
           </div>
           <h3 className="text-2xl font-serif">AI believe in miracles</h3>
           <p className="text-gray-400 font-body text-sm mt-2">Case Study / Motion Art</p>
        </div>
        <div onClick={() => window.open('https://www.instagram.com/animae.ai/', '_blank')} className="group cursor-pointer">
           <div className="aspect-[4/3] bg-gray-50 mb-6 overflow-hidden">
              <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="Animae" />
           </div>
           <h3 className="text-2xl font-serif flex items-center gap-2">Animae.ai <Share2 size={16} /></h3>
           <p className="text-gray-400 font-body text-sm mt-2">Instagram Feed / Digital Identity</p>
        </div>
        <div onClick={() => window.open('https://pin.it/7cHpeOJQc', '_blank')} className="group cursor-pointer md:col-span-2">
           <div className="aspect-[21/9] bg-gray-50 mb-6 overflow-hidden">
              <img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="Digital Content" />
           </div>
           <h3 className="text-2xl font-serif flex items-center gap-2">Digital Content <Share2 size={16} /></h3>
           <p className="text-gray-400 font-body text-sm mt-2">Pinterest Board / Visual Curation</p>
        </div>
    </div>
  </div>
);
